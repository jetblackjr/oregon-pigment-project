# Oregon Pigment Project Field Guide

This is the working name for the project.

## Two-level catalog

### 1. Private collection
Your full specimen database stays on your device. It can contain:
- every specimen
- private notes
- exact GPS
- storage location
- collection details
- processing experiments
- photos

Use **Private Backup** regularly to export everything.

### 2. Public catalog
When you edit a specimen, check **Include this specimen in the public catalog**.

Those specimens can then be exported with **Export Public Catalog**. The public export intentionally leaves out private storage information and collector-only information.

The current version is designed so that the public catalog can eventually be uploaded to a website/database without exposing your whole private collection.

## How to use it on your computer

1. Download the ZIP file.
2. Find it in your Downloads folder.
3. Right-click it and choose **Extract All** (Windows) or double-click it (Mac).
4. Open the extracted folder.
5. Double-click `index.html`.
6. The catalog opens in your web browser.

You can start entering specimens immediately.

## How to use it on your phone

For the first test, you can open the HTML file on a computer.

For the eventual phone app, the project should be put on a secure web address (HTTPS). Then you can open it on your phone and choose **Add to Home Screen**. It will behave much more like a normal app and can request camera/GPS permissions.

## The eventual public website

The long-term version should have:

PRIVATE DATABASE
  ↓
Choose "Include in public catalog"
  ↓
PUBLIC DATABASE
  ↓
Oregon Pigment Project website / searchable map

That will let you keep your complete research collection private while selectively publishing specimens.

The current version uses the device's browser storage, so it is a prototype rather than a cloud database. Do not rely on one device without backups.

## Recommended next development

The next major version should move the data into a real online database with user accounts. That would allow:
- private specimen records
- public specimen records
- public specimen pages
- searchable Oregon pigment map
- specimen-to-pigment processing history
- multiple users/collectors
- permanent image storage
- QR codes for physical specimen jars
- downloadable specimen sheets
- eventually a proper iPhone/Android app


## Visual design and image licensing

Version 3 uses an Oregon field-journal aesthetic with earth/forest/ochre colors and a public-domain Mount Hood hero photograph from the U.S. Fish & Wildlife Service. The image is public domain according to the FWS media page. Additional public-domain Oregon landscape sources include FWS Oregon Coast, Ecola Point, and Oregon sagebrush imagery.

The app contains no AI model, no copy of ChatGPT, no analytics SDK, and no third-party JavaScript libraries. It is ordinary HTML/CSS/JavaScript.

The hero photograph is loaded from the FWS website so the ZIP stays small. When the app is online, your browser requests that image from FWS. For a future fully offline version, we can package local image copies with their credits/licenses.
